class CreatePessoas < ActiveRecord::Migration
  def change
    create_table :pessoas do |t|
      t.string :nome
      t.string :telefone
      t.string :cpf
      t.string :email
      t.string :sexo
      t.string :cidade
      t.string :estado
      t.string :usuario
      t.string :senha

      t.timestamps null: false
    end
  end
end
