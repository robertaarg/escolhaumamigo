class CreateFavoritos < ActiveRecord::Migration
  def change
    create_table :favoritos do |t|
      t.string :data

      t.timestamps null: false
    end
  end
end
