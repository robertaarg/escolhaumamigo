# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20160929024357) do

  create_table "animais", force: :cascade do |t|
    t.string   "nome"
    t.string   "sexo"
    t.string   "porte"
    t.string   "peso"
    t.string   "idade"
    t.string   "tipo"
    t.string   "status"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "favoritos", force: :cascade do |t|
    t.string   "data"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "ongs", force: :cascade do |t|
    t.string   "nome"
    t.string   "telefone"
    t.string   "cnpj"
    t.string   "email"
    t.string   "cidade"
    t.string   "estado"
    t.string   "usuario"
    t.string   "senha"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "pessoas", force: :cascade do |t|
    t.string   "nome"
    t.string   "telefone"
    t.string   "cpf"
    t.string   "email"
    t.string   "sexo"
    t.string   "cidade"
    t.string   "estado"
    t.string   "usuario"
    t.string   "senha"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "racas", force: :cascade do |t|
    t.string   "nome"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

end
