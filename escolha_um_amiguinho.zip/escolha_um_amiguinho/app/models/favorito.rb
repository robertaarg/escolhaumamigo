class Favorito < ActiveRecord::Base
end
