class Raca < ActiveRecord::Base
end
