class Pessoa < ActiveRecord::Base

validates_presence_of :nome, message: "O nome deve ser preenchido"
validates_presence_of :telefone, message: "O telefone deve ser preenchido"
validates_presence_of :cpf, message: "O CPF deve ser preenchido"
validates_presence_of :email, message: "O email deve ser preenchido"
validates_presence_of :sexo, message: "O sexo deve ser preenchido"
validates_presence_of :cidade, message: "A cidade deve ser preenchido"
validates_presence_of :estado, message: "O estado deve ser preenchido"
validates_presence_of :usuario, message: "O usuario deve ser preenchido"
validates_presence_of :senha, message: "O senha deve ser preenchido"

validates_uniqueness_of :usuario, message:"Usuario j. cadastrado"
validates_uniqueness_of :email, message: "Email j. cadastrado"
end
