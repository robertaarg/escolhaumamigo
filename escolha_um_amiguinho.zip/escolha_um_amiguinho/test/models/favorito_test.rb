require 'test_helper'

class FavoritoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
